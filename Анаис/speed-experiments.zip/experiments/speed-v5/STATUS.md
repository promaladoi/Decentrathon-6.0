# Experimental fused MLP — not selected

45 GPU tests passed in 29.37 s under isolated official Triton 3.2.0 / Torch 2.11.0+cu128. The same environment was supplied to base and solution.

Observed full training-process times in the notebook: base_1 77.88 s; solution_1 58.54 s; solution_2 61.79 s; solution peak 8087 MiB. These solution runs were slower than the selected V4 median of 55.68 s and used more memory.

The Kaggle editor stopped exposing its executing iframe before the final result/checks could be exported. Reconnecting remained at “Session is starting”. **There is no exported final result.json/checks.json for V5, and no claim of 10/10 checks for this experiment.** execution-partial.txt preserves the observed UI output. Do not treat this as a complete scored submission.

The production solution remains V4, independently verified with two base and two solution runs, raw result/checks, 43 GPU tests, 79 Soup regression tests and 10/10 checks. Its evidence is in experiments/final and the root speed-result.json/speed-checks.json.
